require File.expand_path("../load", __FILE__)
Service.load_services
