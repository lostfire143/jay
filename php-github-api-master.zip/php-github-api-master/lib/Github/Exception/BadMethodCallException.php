<?php

namespace Github\Exception;

/**
 * BadMethodCallException.
 *
 * @author James Brooks <jbrooksuk@me.com>
 */
class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
