# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.0.1

### Fixed

- Better check if we got a empty result. 

## 4.0.0

First release of this library. 
