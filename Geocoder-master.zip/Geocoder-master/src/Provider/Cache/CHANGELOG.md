# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0 (2018-03-16)

* Changed: `ProviderCache` is no longer final allowing `ProviderCache::getCacheKey` to be overridden

## 4.0.1

### Changed

- Using stable requirement of `willdurand/geocoder`.

## 4.0.0

First release of this library. 
