# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0

- Support for localized requests. 

## 4.0.1

- Better check if it was an empty result. 

## 4.0.0

First release of this library. 
