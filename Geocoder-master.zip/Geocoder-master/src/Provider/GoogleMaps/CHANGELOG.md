# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.3.0

### Added

- Added [component filtering](https://developers.google.com/maps/documentation/geocoding/intro#ComponentFiltering).

## 4.2.0

### Added

- Added the `$channel` constructor parameter.

## 4.1.0

### Added

- Support for `SubLocality`. 

## 4.0.0

First release of this library. 
