# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0

### Added

- Added CountryInfo endpoint

### Fixed

- Check if response key exists to avoid notice. 

## 4.0.0

First release of this library. 
