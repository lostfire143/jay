# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0

### Changed

Updated dependencies, make sure `Country` never is without data.

## 4.0.0

First release of this library. 
