# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.1.0

### Added

- Added `OpenCageAddress` model.
  - Added `MGRS`
  - Added `Maidenhead`
  - Added `geohash`
  - Added `what3words`
  - Added formatted address

## 4.0.0

First release of this library. 
