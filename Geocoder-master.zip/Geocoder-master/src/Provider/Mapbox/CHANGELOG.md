# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 1.0.1

### Fixed

- Fix the Bounds query builder format

## 1.0.0

First release of this library. 
