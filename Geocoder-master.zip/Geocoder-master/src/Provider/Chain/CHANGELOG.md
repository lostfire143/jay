# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 4.0.0

No changes since Beta 1.

## 4.0.0 - Beta 1

First release of this library. 
